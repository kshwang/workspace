"use strict";

function call(param){
    return ("Hello, " + param);
}