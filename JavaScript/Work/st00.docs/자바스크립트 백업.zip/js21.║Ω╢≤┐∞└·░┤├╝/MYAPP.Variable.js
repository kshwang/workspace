
"use strict";

var MYAPP =  {};